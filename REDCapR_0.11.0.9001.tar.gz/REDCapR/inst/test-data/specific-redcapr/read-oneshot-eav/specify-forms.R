structure(list(record_id = 1:5, name_first = c("Nutmeg", "Tumtum", 
"Marcus", "Trudy", "John Lee"), name_last = c("Nutmouse", "Nutmouse", 
"Wood", "DAG", "Walker"), address = c("14 Rose Cottage St.\nKenning UK, 323232", 
"14 Rose Cottage Blvd.\nKenning UK 34243", "243 Hill St.\nGuthrie OK 73402", 
"342 Elm\nDuncanville TX, 75116", "Hotel Suite\nNew Orleans LA, 70115"
), telephone = c("(405) 321-1111", "(405) 321-2222", "(405) 321-3333", 
"(405) 321-4444", "(405) 321-5555"), email = c("nutty@mouse.com", 
"tummy@mouse.comm", "mw@mwood.net", "peroxide@blonde.com", "left@hippocket.com"
), dob = c("2003-08-30", "2003-03-10", "1934-04-09", "1952-11-02", 
"1955-04-15"), age = c(11L, 11L, 80L, 61L, 59L), sex = c(0L, 
1L, 1L, 0L, 1L), race___1 = c(FALSE, FALSE, FALSE, FALSE, TRUE
), race___2 = c(FALSE, FALSE, FALSE, TRUE, FALSE), race___3 = c(FALSE, 
TRUE, FALSE, FALSE, FALSE), race___4 = c(FALSE, FALSE, TRUE, 
FALSE, FALSE), race___5 = c(TRUE, TRUE, TRUE, TRUE, FALSE), race___6 = c(FALSE, 
FALSE, FALSE, FALSE, TRUE), ethnicity = c(1L, 1L, 0L, 1L, 2L), 
    interpreter_needed = c(0L, 0L, 1L, NA, 0L), demographics_complete = c(2L, 
    2L, 2L, 2L, 2L), race_and_ethnicity_complete = c(2L, 0L, 
    2L, 2L, 2L)), row.names = c(NA, -5L), class = c("tbl_df", 
"tbl", "data.frame"))
