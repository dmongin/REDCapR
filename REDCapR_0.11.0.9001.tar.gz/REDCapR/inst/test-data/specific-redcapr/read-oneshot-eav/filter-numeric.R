structure(list(record_id = 3:4, name_first = c("Marcus", "Trudy"
), name_last = c("Wood", "DAG"), address = c("243 Hill St.\nGuthrie OK 73402", 
"342 Elm\nDuncanville TX, 75116"), telephone = c("(405) 321-3333", 
"(405) 321-4444"), email = c("mw@mwood.net", "peroxide@blonde.com"
), dob = c("1934-04-09", "1952-11-02"), age = c(80L, 61L), sex = 1:0, 
    height = c(180L, 165L), weight = c(80L, 54L), bmi = c(24.7, 
    19.8), comments = c("completely made up", "This record doesn't have a DAG assigned\n\nSo call up Trudy on the telephone\nSend her a letter in the mail"
    ), mugshot = c(197979L, 198002L), race___1 = c(FALSE, FALSE
    ), race___2 = c(FALSE, TRUE), race___3 = c(FALSE, FALSE), 
    race___4 = c(TRUE, FALSE), race___5 = c(TRUE, TRUE), race___6 = c(FALSE, 
    FALSE), ethnicity = 0:1, interpreter_needed = c(1L, NA), 
    demographics_complete = c(2L, 2L), health_complete = c(2L, 
    2L), race_and_ethnicity_complete = c(2L, 2L)), row.names = c(NA, 
-2L), class = c("tbl_df", "tbl", "data.frame"))
