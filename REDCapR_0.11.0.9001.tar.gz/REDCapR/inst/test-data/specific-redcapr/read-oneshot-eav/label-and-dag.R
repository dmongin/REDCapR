structure(list(record_id = 1:5, name_first = c("Nutmeg", "Tumtum", 
"Marcus", "Trudy", "John Lee"), name_last = c("Nutmouse", "Nutmouse", 
"Wood", "DAG", "Walker"), address = c("14 Rose Cottage St.\nKenning UK, 323232", 
"14 Rose Cottage Blvd.\nKenning UK 34243", "243 Hill St.\nGuthrie OK 73402", 
"342 Elm\nDuncanville TX, 75116", "Hotel Suite\nNew Orleans LA, 70115"
), telephone = c("(405) 321-1111", "(405) 321-2222", "(405) 321-3333", 
"(405) 321-4444", "(405) 321-5555"), email = c("nutty@mouse.com", 
"tummy@mouse.comm", "mw@mwood.net", "peroxide@blonde.com", "left@hippocket.com"
), dob = c("2003-08-30", "2003-03-10", "1934-04-09", "1952-11-02", 
"1955-04-15"), age = c(11L, 11L, 80L, 61L, 59L), sex = c("Female", 
"Male", "Male", "Female", "Male"), height = c(7, 6, 180, 165, 
193.04), weight = c(1L, 1L, 80L, 54L, 104L), bmi = c(204.1, 277.8, 
24.7, 19.8, 27.9), comments = c("Character in a book, with some guessing", 
"A mouse character from a good book", "completely made up", "This record doesn't have a DAG assigned\n\nSo call up Trudy on the telephone\nSend her a letter in the mail", 
"Had a hand for trouble and a eye for cash\n\nHe had a gold watch chain and a black mustache"
), mugshot = c(197977L, 197978L, 197979L, 198002L, 198021L), 
    race___1 = c(FALSE, FALSE, FALSE, FALSE, FALSE), race___2 = c(FALSE, 
    FALSE, FALSE, FALSE, FALSE), race___3 = c(FALSE, FALSE, FALSE, 
    FALSE, FALSE), race___4 = c(FALSE, FALSE, FALSE, FALSE, FALSE
    ), race___5 = c(FALSE, FALSE, FALSE, FALSE, FALSE), race___6 = c(FALSE, 
    FALSE, FALSE, FALSE, FALSE), ethnicity = c("NOT Hispanic or Latino", 
    "NOT Hispanic or Latino", "Unknown / Not Reported", "NOT Hispanic or Latino", 
    "Hispanic or Latino"), interpreter_needed = c("False", "False", 
    "True", NA, "False"), demographics_complete = c("Complete", 
    "Complete", "Complete", "Complete", "Complete"), health_complete = c("Unverified", 
    "Incomplete", "Complete", "Complete", "Incomplete"), race_and_ethnicity_complete = c("Complete", 
    "Incomplete", "Complete", "Complete", "Complete")), row.names = c(NA, 
-5L), class = c("tbl_df", "tbl", "data.frame"))
