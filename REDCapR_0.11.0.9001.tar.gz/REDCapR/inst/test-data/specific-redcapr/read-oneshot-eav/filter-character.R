structure(list(record_id = 5L, name_first = "John Lee", name_last = "Walker", 
    address = "Hotel Suite\nNew Orleans LA, 70115", telephone = "(405) 321-5555", 
    email = "left@hippocket.com", dob = "1955-04-15", age = 59L, 
    sex = 1L, height = 193.04, weight = 104L, bmi = 27.9, comments = "Had a hand for trouble and a eye for cash\n\nHe had a gold watch chain and a black mustache", 
    mugshot = 198021L, race___1 = TRUE, race___2 = FALSE, race___3 = FALSE, 
    race___4 = FALSE, race___5 = FALSE, race___6 = TRUE, ethnicity = 2L, 
    interpreter_needed = 0L, demographics_complete = 2L, health_complete = 0L, 
    race_and_ethnicity_complete = 2L), row.names = c(NA, -1L), class = c("tbl_df", 
"tbl", "data.frame"))
