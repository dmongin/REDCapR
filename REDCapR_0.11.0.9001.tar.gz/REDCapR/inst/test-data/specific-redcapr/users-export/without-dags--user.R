structure(list(username = c("unittestphifree", "wbeasleya"), 
    email = c("wibeasley@hotmail.com", "william-beasley@ouhsc.edu"
    ), firstname = c("Unit Test", "Will"), lastname = c("PHI Free", 
    "Beasley_A"), expiration = structure(c(NA_real_, NA_real_
    ), class = "Date"), data_access_group = c(NA_character_, 
    NA_character_), data_access_group_id = c(NA_character_, NA_character_
    ), design = c(FALSE, TRUE), user_rights = c(FALSE, TRUE), 
    data_access_groups = c(FALSE, TRUE), data_export = c("1", 
    "1"), reports = c(TRUE, TRUE), stats_and_charts = c(TRUE, 
    TRUE), manage_survey_participants = c(TRUE, TRUE), calendar = c(TRUE, 
    TRUE), data_import_tool = c(FALSE, TRUE), data_comparison_tool = c(FALSE, 
    TRUE), logging = c(FALSE, TRUE), file_repository = c(TRUE, 
    TRUE), data_quality_create = c(FALSE, TRUE), data_quality_execute = c(FALSE, 
    TRUE), api_export = c(TRUE, FALSE), api_import = c(FALSE, 
    FALSE), mobile_app = c(FALSE, FALSE), mobile_app_download_data = c(FALSE, 
    FALSE), record_create = c(TRUE, TRUE), record_rename = c(FALSE, 
    FALSE), record_delete = c(FALSE, FALSE), lock_records_all_forms = c(FALSE, 
    FALSE), lock_records = c(FALSE, FALSE), lock_records_customization = c(FALSE, 
    FALSE)), row.names = c(NA, -2L), class = c("tbl_df", "tbl", 
"data.frame"))
