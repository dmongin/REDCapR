structure(list(username = c("unittestphifree", "unittestphifree", 
"unittestphifree", "wbeasleya", "wbeasleya", "wbeasleya"), form_name = c("demographics", 
"health", "race_and_ethnicity", "demographics", "health", "race_and_ethnicity"
), permission_id = c(1L, 1L, 1L, 1L, 1L, 1L), permission = structure(c(3L, 
3L, 3L, 3L, 3L, 3L), .Label = c("no_access", "readonly", "edit_form", 
"edit_survey", "unknown"), class = "factor")), row.names = c(NA, 
-6L), class = c("tbl_df", "tbl", "data.frame"))
