structure(list(username = c("unittestphifree", "wbeasleya"), 
    email = c("wibeasley@hotmail.com", "william-beasley@ouhsc.edu"
    ), firstname = c("Unit Test", "Will"), lastname = c("PHI Free", 
    "Beasley_A"), expiration = structure(c(NA_real_, NA_real_
    ), class = "Date"), data_access_group = c("daga", NA), data_access_group_id = c("331", 
    NA), design = c(FALSE, TRUE), user_rights = c(FALSE, TRUE
    ), data_access_groups = c(FALSE, TRUE), data_export = c("1", 
    "1"), reports = c(FALSE, TRUE), stats_and_charts = c(FALSE, 
    TRUE), manage_survey_participants = c(TRUE, TRUE), calendar = c(FALSE, 
    TRUE), data_import_tool = c(FALSE, TRUE), data_comparison_tool = c(FALSE, 
    TRUE), logging = c(FALSE, TRUE), file_repository = c(FALSE, 
    TRUE), data_quality_create = c(FALSE, TRUE), data_quality_execute = c(FALSE, 
    TRUE), api_export = c(TRUE, TRUE), api_import = c(FALSE, 
    TRUE), mobile_app = c(FALSE, TRUE), mobile_app_download_data = c(FALSE, 
    TRUE), record_create = c(FALSE, TRUE), record_rename = c(FALSE, 
    FALSE), record_delete = c(FALSE, FALSE), lock_records_all_forms = c(FALSE, 
    FALSE), lock_records = c(FALSE, FALSE), lock_records_customization = c(FALSE, 
    FALSE)), row.names = c(NA, -2L), class = c("tbl_df", "tbl", 
"data.frame"))
