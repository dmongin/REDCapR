structure(list(username = c("unittestphifree", "wbeasleya"), 
    form_name = c("demographics", "demographics"), permission_id = c(1L, 
    1L), permission = structure(c(3L, 3L), .Label = c("no_access", 
    "readonly", "edit_form", "edit_survey", "unknown"), class = "factor")), row.names = c(NA, 
-2L), class = c("tbl_df", "tbl", "data.frame"))
